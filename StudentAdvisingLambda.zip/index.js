'use strict'
const alexaSkillKit = require('alexa-skill-kit')
const MessageTemplate = require('alexa-message-builder')
const MySql = require('sync-mysql');
const Alexa = require('ask-sdk-core');

const CARD_TITLE = 'San Jose State Advising Bot';
const HELP_MESSAGE =  `I can give you the info about Adding, Dropping, or Registering for Classes Questions, Time off, Holds, Probation, or Disqualification Questions and various other Miscellaneous Frequently Asked Questions.
			                  How can I help you today? You can say Alexa do you know and then your question or
			                  Alexa could you tell me more about and then your question`;
const WELCOME_MESSAGE = `Hello from San Jose State Advising bot! ${HELP_MESSAGE}`;
const ERROR_MESSAGE = 'An error occurred while processing your request. Please check back in sometime';
const connDetails = {
            host     : 'studentadvising.ctahqekfkony.us-east-1.rds.amazonaws.com',
            port     :  3306,
            user     : 'sjsu',
            password : '11223344',
            database : 'SJSU_Advising'
        };

function InsertQuestion(connection,question){
    connection.query(`INSERT INTO advising.Unanswered(question, question_hash, asked_on)
                             VALUES(?, md5(?), now())`,[question, question]);
}

function InsertFeedback(connection,question, answer){
  console.log(question);
  console.log(answer);
    connection.query(`INSERT INTO advising.Feedback(question, answer, asked_on)
                             VALUES(?, ?, now())`,[question, answer]);
}

const LaunchRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
  },
  handle(handlerInput) {
    return handlerInput.responseBuilder
      .speak(WELCOME_MESSAGE)
      .reprompt(WELCOME_MESSAGE)
      .withSimpleCard(CARD_TITLE, WELCOME_MESSAGE)
      .getResponse();
  },
};

const QuestionHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
&&  handlerInput.requestEnvelope.request.intent.name === 'Advising';
  },
  handle(handlerInput) {
    const sessionAttributes = handlerInput.requestEnvelope.request.intent.slots.question.value;
    console.log(sessionAttributes);
    let speechText = '';

    if (typeof sessionAttributes === 'undefined') {
      speechText = 'Please ask your question.';
    } else {
      const token = sessionAttributes;
      console.log(token);
      const connection = new MySql(connDetails);
      const factArr = connection.query(`SELECT IFNULL((
                        SELECT answer FROM advising.Answers a INNER JOIN advising.Questions q 
                        ON q.Answer_id = a.id 
                        WHERE MATCH(question)  AGAINST (? IN NATURAL LANGUAGE MODE) > 1.5 LIMIT 1), 
                        'I am not sure of this question right now. I have sent your question to the advisor. Please check back in few days.') 
                        as ans`, [token]);
        if(factArr[0].ans === 'I am not sure of this question right now. I have sent your question to the advisor. Please check back in few days.'){
            InsertQuestion(connection,token);
            factArr[0].ans = factArr[0].ans + ' Is there anything else I can help you with today?';
        }
        else{
          factArr[0].ans = factArr[0].ans + 
          '\n Did you find the information useful? You could say Useful or Not Useful to give us the feedback!';
        }
				console.log(factArr);
				connection.dispose();
				handlerInput.attributesManager.setSessionAttributes({"lastques":token, "lastans":factArr[0].ans});
				speechText = factArr[0].ans;
    }

    return handlerInput.responseBuilder
      .speak(speechText)
      .reprompt("Do you have more questions for me?")
      .withSimpleCard(CARD_TITLE, speechText)
      .getResponse();
  },
};

const YesIntentHandler = {
   canHandle(handlerInput) {
     return handlerInput.requestEnvelope.request.type === 'IntentRequest'
     && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.YesIntent';
   },
   handle(handlerInput) {
    return handlerInput.responseBuilder
      .speak("Go ahead! Ask me!")
      .reprompt(" Do you have more questions for me?")
      .withSimpleCard(CARD_TITLE, HELP_MESSAGE)
      .getResponse();
  },
};

const undefinedHandler = {
  canHandle(handlerInput){
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
    && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.FallbackIntent';
  },
  handle(handlerInput) {
     var resp = `I don't understand the question. You could say Alexa do you know and then your question or
			                 Alexa could you tell me more about and then your question`;
    return handlerInput.responseBuilder
      .speak(resp)
      .reprompt("Do you have more questions for me?")
      .withSimpleCard(CARD_TITLE, HELP_MESSAGE)
      .getResponse();
  }
}
const NoIntentRequest = {
  canHandle(handlerInput) {
     return handlerInput.requestEnvelope.request.type === 'IntentRequest'
     && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.NoIntent';
   },
   handle(handlerInput) {
     const utcDate = new Date();
     utcDate.setHours(utcDate.getHours()-8);
     const usDate = new Date(utcDate);
     console.log(usDate);
     const current_hour = usDate.getHours();
     console.log(current_hour);
     const Message = current_hour >= 17 && current_hour <= 20 ? 'Have a Good Evening!' : ((current_hour > 20 || 
                    (current_hour >= 0 && current_hour <= 4)) ? 'Have a Good Night!' : 'Have a Good Day!'); 
     var resp = "Thanks for visiting San Jose State Advising Bot. " + Message;
    return handlerInput.responseBuilder
      .speak(resp)
      .withSimpleCard(CARD_TITLE, HELP_MESSAGE)
      .getResponse();
  },
};

const FeedbackIntentHandler = {
  canHandle(handlerInput) {
     return handlerInput.requestEnvelope.request.type === 'IntentRequest'
     && handlerInput.requestEnvelope.request.intent.name === 'UsefulFeedback';
   },
   handle(handlerInput) {
     
     var resp = "Thanks for your feedback. Is there anything else I can help you with today?";
    return handlerInput.responseBuilder
      .speak(resp)
      .reprompt(resp)
      .withSimpleCard(CARD_TITLE, HELP_MESSAGE)
      .getResponse();
  },
};

const NotUsefulFeedbackIntentHandler = {
  canHandle(handlerInput) {
     return handlerInput.requestEnvelope.request.type === 'IntentRequest'
     && handlerInput.requestEnvelope.request.intent.name === 'NotUsefulFeedback';
   },
   handle(handlerInput) {
     const lastQuestionAsked = handlerInput.attributesManager.getSessionAttributes();
     const connection = new MySql(connDetails);
     //console.log(lastQuestionAsked.lastans);
     InsertFeedback(connection,lastQuestionAsked.lastques, lastQuestionAsked.lastans);
     connection.dispose();
     var resp = `Thanks for your feedback. I have sent your question to advisor for review. Please check back in few days. 
     Is there anything else I can help you with today?`;
    return handlerInput.responseBuilder
      .speak(resp)
      .reprompt(resp)
      .withSimpleCard(CARD_TITLE, HELP_MESSAGE)
      .getResponse();
  },
};

const HelpIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {
    return handlerInput.responseBuilder
      .speak(HELP_MESSAGE)
      .reprompt(HELP_MESSAGE)
      .withSimpleCard(CARD_TITLE, HELP_MESSAGE)
      .getResponse();
  },
};


const CancelAndStopIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
        || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
  },
  handle(handlerInput) {
    const speechText = 'The connection with the advising bot was terminated!';

    return handlerInput.responseBuilder
      .speak(speechText)
      .withSimpleCard(CARD_TITLE, speechText)
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

    return handlerInput.responseBuilder.getResponse();
  },
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    console.log(handlerInput.requestEnvelope.request);
    console.log(`Error handled: ${error.message}`);

    return handlerInput.responseBuilder
      .speak(ERROR_MESSAGE)
      .withSimpleCard(CARD_TITLE, ERROR_MESSAGE)
      .getResponse();
  },
};



const skillBuilder = Alexa.SkillBuilders.custom();
exports.handler = skillBuilder
  .addRequestHandlers(
    LaunchRequestHandler,
    QuestionHandler,
    HelpIntentHandler,
    CancelAndStopIntentHandler,
    SessionEndedRequestHandler,
    YesIntentHandler,
    NoIntentRequest,
    FeedbackIntentHandler,
    NotUsefulFeedbackIntentHandler,
    undefinedHandler
  )
  .addErrorHandlers(ErrorHandler)
  .lambda();